module.exports = {
  id: String,
  subscription: Object
};
