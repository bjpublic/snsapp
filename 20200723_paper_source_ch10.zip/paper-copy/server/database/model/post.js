module.exports = {
  id: Number,
  author: String,
  title: String,
  date: String,
  content: String,
  image: String,
  favorite: Array
};
